// The anonymous message form is hosted by Jotform.
// The button in index.html opens your Jotform form in a new tab.
